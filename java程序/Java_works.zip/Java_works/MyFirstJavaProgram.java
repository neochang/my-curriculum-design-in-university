//��һ��Java Application ����MyFirstJavaProgram.java
import java.io.*;
public class MyFirstJavaProgram
{
	public static void main(String args[])
	{
		System.out.println("This is my firs Java program!");
	}
}	