import java.applet.Applet;
import java.awt.*;

public class Exp4_4 extends Applet
{